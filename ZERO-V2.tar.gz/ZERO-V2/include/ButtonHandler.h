/**
 * ButtonHandler.h - Button input handling with debouncing
 */

#ifndef BUTTON_HANDLER_H
#define BUTTON_HANDLER_H

#include <Arduino.h>
#include "Config.h"

class Button {
private:
    uint8_t pin;
    bool lastState;
    bool currentState;
    unsigned long lastDebounceTime;
    unsigned long pressStartTime;
    bool longPressTriggered;
    
public:
    Button(uint8_t pin);
    void begin();
    ButtonEvent update();
};

class ButtonHandler {
private:
    Button btnUp;
    Button btnDown;
    Button btnSelect;
    Button btnMode;
    
public:
    ButtonHandler();
    void begin();
    ButtonEvent update();
    
    // Individual button checks
    bool isUpPressed();
    bool isDownPressed();
    bool isSelectPressed();
    bool isModePressed();
};

#endif // BUTTON_HANDLER_H
